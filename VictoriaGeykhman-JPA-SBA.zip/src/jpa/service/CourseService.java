package jpa.service;

import java.util.List;

import jpa.dao.AbstractDAO;
import jpa.dao.CourseDAO;
import jpa.entitymodels.Course;

public class CourseService extends AbstractDAO implements CourseDAO {

	@Override
	public List<Course> getAllCourses() {
		// TODO Auto-generated method stub
		return null;
	}

}//public class CourseService
